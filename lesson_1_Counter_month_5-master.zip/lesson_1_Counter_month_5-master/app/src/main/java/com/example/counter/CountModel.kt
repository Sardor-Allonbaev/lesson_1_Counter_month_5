package com.example.counter

class CountModel {

    var count = 0

    fun increment(){
        count++
    }

    fun decrement(){
        count--
    }
}